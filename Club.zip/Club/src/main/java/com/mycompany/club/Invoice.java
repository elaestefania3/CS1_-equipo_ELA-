package com.mycompany.club;

public class Invoice {
    private String invoiceConcept;
    private double value;

    public Invoice(String invoiceConcept, double value) {
        this.invoiceConcept = invoiceConcept;
        this.value = value;
    }

    public String getInvoiceConcept() {
        return invoiceConcept;
    }

    public double getValue() {
        return value;
    }
}
