package com.mycompany.club;

public class UnpaidInvoicesException extends Exception {
    public UnpaidInvoicesException(String message) {
        super(message);
    }
}
