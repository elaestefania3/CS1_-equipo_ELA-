package com.mycompany.club;

import java.util.ArrayList;

public class Club {
    public ArrayList<Member> members;

    public Club() { //constructor para listar socios
        this.members = new ArrayList<>();
    }

    public void addMember(Member member) {
        if (members.size() < 35) { //para un máx. de 35 socios
            for (Member i : members) {
                if (i.getPersonId() == member.getPersonId()) { //busca id socio
                    System.out.println("El socio ya existe.");
                    return; //salir si  socio existe
                }
            }
            members.add(member); //agregar socio
            System.out.println("El socio ha sido agregado.");
        } else {
            System.out.println("No se pueden ingresar más socios.");
        }
    }

    public boolean removeMember(int personId) {
    Member memberToRemove = null;
    for (Member member : members) {
        if (member.getPersonId() == personId) {
            memberToRemove = member;
            break;
        }
    }
    try {
        if (memberToRemove == null) {
            throw new MemberNotFoundException("El socio no existe.");
        }
        if (memberToRemove.getSubscriptionType().equalsIgnoreCase("VIP")) {
            throw new VIPMemberRemovalException("No se pueden eliminar los socios VIP.");
        }
        if (!memberToRemove.getUnpaidInvoices().isEmpty()) {
            throw new UnpaidInvoicesException("No se pueden eliminar socios con facturas pendientes.");
        }
        if (memberToRemove.getAuthorizedPersons().size()>=1) {
            throw new ThereAreAuthorizedPersonsException("No se pueden eliminar socios con personas autorizadas.");
        }

        members.remove(memberToRemove);
        System.out.println("Se ha eliminado el socio.");
        return true;

    } catch (MemberNotFoundException | VIPMemberRemovalException | UnpaidInvoicesException | ThereAreAuthorizedPersonsException e) {
        System.out.println(e.getMessage());
        return false;
    }
}
    public boolean removeAuthorizedPerson(int memberId, int authorizedPersonId) {
        for (Member member:members) {
            if (member.getPersonId()==memberId) {
                return member.removeAuthorizedPerson(authorizedPersonId); //manda al método eliminar 
            }
        }
        System.out.println("El socio no existe.");
        return false;
    }
}
