package com.mycompany.club;

import java.util.ArrayList;

public class Member extends Person {
    private double availableFunds;
    private String subscriptionType;
    ArrayList<Invoice> unpaidInvoices; //facturas sin pagar
    ArrayList<Person> authorizedPersons; //personas autorizadas

    //constructor para tomar datos de Person y propios
    public Member(int id, String name, String subscriptionType) {
        super(id, name); // por herencia llama el constructor de clase Person
        this.subscriptionType = subscriptionType;

        //fondo inicial: 100 mil si es VIP - 50 mil si es regular
        if (subscriptionType.equals("VIP")) {
            this.availableFunds = 100000;
        } else {
            this.availableFunds = 50000;
        }

        //inicializa listas de facturas sin pagar y personas autorizadas
        this.unpaidInvoices = new ArrayList<>();
        this.authorizedPersons = new ArrayList<>();
    }

    //get y set
    public double getAvailableFunds() {
        return availableFunds;
    }

    public void setAvailableFunds(double availableFunds) {
        this.availableFunds = availableFunds;
    }

    public String getSubscriptionType() {
        return subscriptionType;
    }

    public void setSubscriptionType(String subscriptionType) {
        this.subscriptionType = subscriptionType;
    }

    public ArrayList<Invoice> getUnpaidInvoices() {
        return unpaidInvoices;
    }

    public ArrayList<Person> getAuthorizedPersons() {
        return authorizedPersons;
    }
    public void addAuthorizedPerson(Person person) {
        try {
            if (authorizedPersons.size()<10) {
                authorizedPersons.add(person);
                System.out.println("Se agrega a la persona autorizada.");
            } else {
                throw new Exception("No puede superar el tope de personas a asociar: 10.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public boolean removeAuthorizedPerson(int authorizedPersonId) {
        for (Person authorized : authorizedPersons) {
            if (authorized.getPersonId() == authorizedPersonId) {
                authorizedPersons.remove(authorized);
                return true; //true si se eliminó persona aut.
            }
        }
        return false; //  false si no
    }

    public void addInvoice(Invoice invoice){//agregar  factura a facturas sin pagar
        unpaidInvoices.add(invoice);
    }

    public boolean payInvoice(Invoice invoice){   //método pagar factura
    if (unpaidInvoices.remove(invoice)) {
        availableFunds -= invoice.getValue(); //resta valor de la factura de los fondos disponibles
        System.out.println("Fondos suficientes.");
        return true; // si se pagó 
    } else {
        System.out.println("Factura no encontrada.");
        return false;
    }
}
}
/* return true; 
        } else {
            System.out.println("Fondos insuficientes p.");
        }
    } else {
        System.out.println("Factura no encontrada.");
    }
    return false; // Retorna false si no se pudo realizar el pago
}*/