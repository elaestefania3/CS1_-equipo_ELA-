package com.mycompany.club;

public class VIPMemberRemovalException extends Exception {
    public VIPMemberRemovalException(String message) {
        super(message);
    }
}
