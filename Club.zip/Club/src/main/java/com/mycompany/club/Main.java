package com.mycompany.club;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Club club = new Club(); //instancia del club
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("-- CLUB SOCIAL --");
            System.out.println("1. Agregar socio");
            System.out.println("2. Eliminar socio");
            System.out.println("3. Agregar persona autorizada");
            System.out.println("4. Eliminar persona autorizada");
            System.out.println("5. Pagar factura");
            System.out.println("6. Salir");
            System.out.print("Seleccione una de las opciones: ");
            choice = scanner.nextInt();
            scanner.nextLine(); //escribir en la misma línea que imprime

            switch (choice) {
                case 1: 
                    System.out.println("-- REGISTRO DE SOCIOS --");
                    System.out.print("Nro. de documento: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Nombre: ");
                    String name = scanner.nextLine();
                    System.out.print("Suscribir como VIP o Regular: ");
                    String subscriptionType = scanner.nextLine();

                    Member newMember = new Member(id, name, subscriptionType); //instancia para crear socio
                    club.addMember(newMember); //método para agregar al socio
                    break;

               case 2:
                    System.out.println("-- ELIMINAR SOCIO --");
                    System.out.print("Nro. de documento: ");
                    int personId = scanner.nextInt();
                    club.removeMember(personId); //método para eliminar socio
                    break;

                case 3:
                    System.out.println("-- REGISTRO DE PERSONAS AUTORIZADAS --");
                    System.out.print("Nro. de documento del socio: ");
                    int memberIdForAuthorizedPerson = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nro. de documento de la persona autorizada: ");
                    int authorizedPersonId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nombre de la persona autorizada: ");
                    String authorizedPersonName = scanner.nextLine();

                    Person authorizedPerson = new Person(authorizedPersonId, authorizedPersonName) {}; //instancia para crear persona autorizada
                    for (Member member : club.members) {//busca socio en la lista y cuando encuentra el ID agrega a la persona autorizada
                        if (member.getPersonId() == memberIdForAuthorizedPerson) {
                            member.addAuthorizedPerson(authorizedPerson); //asocia persona autorizada al socio
                            break;//rompe for para no buscar màs
                        }
                    }
                    break;

                case 4:
                    System.out.println("-- ELIMINAR PERSONA AUTORIZADA --");
                    System.out.print("Nro. de documento del socio: ");
                    int socioId = scanner.nextInt();
                    System.out.print("Nro. de documento de la persona autorizada: ");
                    int personIdToRemove = scanner.nextInt();
                    boolean removed = club.removeAuthorizedPerson(socioId, personIdToRemove); // Método para eliminar persona autorizada
                    if (removed) {
                        System.out.println("Persona autorizada eliminada.");
                    } else {
                        System.out.println("No existe la persona autorizada.");
                    }
                    break;

                case 5:
                    System.out.println("-- PAGAR FACTURA --");
                System.out.print("Nro. de documento del socio: ");
                int socioIdForInvoice = scanner.nextInt();
                    scanner.nextLine();
                    Member foundMember = null;//buscar el socio primero
                    for (Member member : club.members) {
                        if (member.getPersonId() == socioIdForInvoice) {
                        foundMember = member; //almacena id del socio
                        break;
                        }
                    }
                    if (foundMember != null) {     //  si socio existe
                        System.out.print("Nro. de factura: ");
                        String invoiceNumber = scanner.nextLine();
                        System.out.print("Valor: ");
                        double value = scanner.nextDouble();
                        Invoice invoice = new Invoice(invoiceNumber, value); // instancia para factura

                        foundMember.addInvoice(invoice); //asociar factura al socio
                        boolean paymentSuccessful = foundMember.payInvoice(invoice); // Pagar factura
                        if (paymentSuccessful) {
                            System.out.println("Pago exitoso.");
                        } else {
                            System.out.println("No se pudo realizar el pago.");
                        }
                } else {
                        System.out.println("El socio no existe.");
                    }
                    break;

                case 6:
                    System.out.println("Salida exitosa.");
                    break;

                default:
                    System.out.println("Incorrecto, intente de nuevo.");
            }
            System.out.println();
        } while (choice != 6);

        scanner.close();
    }
}
