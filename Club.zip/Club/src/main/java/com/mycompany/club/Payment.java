package com.mycompany.club;

public interface Payment {//direcctrices que deben cumplir las clases, como las abstractas
    void addInvoice(Invoice invoice);//para implemnetar en los métodos de member 
    boolean payInvoice(Invoice invoice);//confirmar pago o no
}
