package com.mycompany.club;

public class ThereAreAuthorizedPersonsException extends Exception {
    public ThereAreAuthorizedPersonsException(String message) {
        super(message);
    }
}
