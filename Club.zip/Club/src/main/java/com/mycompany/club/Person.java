package com.mycompany.club;

public abstract class Person {//para adaptar a x tipos de persona / socio
    protected int personId;
    protected String personName;

    public Person(int personId, String personName) {    //constructor persona autorizada
        this.personId = personId;
        this.personName = personName;
    }

    //get y set para personId
    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    //get y set para personName
    public String getPersonName() {
        return personName;
    }
    public void setPersonName(String personName) {
        this.personName = personName;
    }//falta método para person
}
